# MT5 file bridge starter for Windows.
# Run from repo root:  .\mt5-bridge\windows\StartBridge.ps1
# Do NOT use: cd StartBridge.ps1  (cd is only for folders; use .\StartBridge.ps1 to run)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Get-Mt5FilesActivityScore {
  param([string]$FilesDir)
  $score = 0
  foreach ($sub in @('mt5-commands', 'mt5-responses')) {
    $p = Join-Path $FilesDir $sub
    if (Test-Path -LiteralPath $p) {
      $cutoff = (Get-Date).AddHours(-24)
      $recent = Get-ChildItem -LiteralPath $p -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -gt $cutoff }
      if ($recent) { $score += 1000 }
    }
  }
  if (Test-Path -LiteralPath $FilesDir) {
    $score += [int64](Get-Item -LiteralPath $FilesDir).LastWriteTimeUtc.Ticks
  }
  return $score
}

function Find-Mt5FilesDir {
  param([string]$TerminalRoot)
  if (-not (Test-Path -LiteralPath $TerminalRoot)) { return $null }
  $best = $null
  $bestScore = -1
  $terminals = Get-ChildItem -LiteralPath $TerminalRoot -Directory -ErrorAction SilentlyContinue
  foreach ($t in $terminals) {
    $files = Join-Path $t.FullName "MQL5\Files"
    if (Test-Path -LiteralPath $files) {
      $s = Get-Mt5FilesActivityScore -FilesDir $files
      if ($s -gt $bestScore) { $bestScore = $s; $best = $files }
    }
  }
  return $best
}

function Find-BestMt5FilesDir {
  $candidates = @()
  $terminalRoot = Join-Path $env:APPDATA "MetaQuotes\Terminal"
  $fromAppData = Find-Mt5FilesDir -TerminalRoot $terminalRoot
  if ($fromAppData) { $candidates += $fromAppData }

  if ($env:LOCALAPPDATA) {
    $localRoot = Join-Path $env:LOCALAPPDATA "MetaQuotes\Terminal"
    $fromLocal = Find-Mt5FilesDir -TerminalRoot $localRoot
    if ($fromLocal -and $candidates -notcontains $fromLocal) { $candidates += $fromLocal }
  }

  foreach ($pf in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
    if ($pf) {
      $direct = Join-Path $pf "MetaTrader 5\MQL5\Files"
      if ((Test-Path -LiteralPath $direct) -and ($candidates -notcontains $direct)) {
        $candidates += $direct
      }
    }
  }

  $best = $null
  $bestScore = -1
  foreach ($c in $candidates) {
    $s = Get-Mt5FilesActivityScore -FilesDir $c
    if ($s -gt $bestScore) { $bestScore = $s; $best = $c }
  }
  return $best
}

function Resolve-PythonLaunch {
  # Windows Store ships a fake python.exe under WindowsApps that only opens the Store — skip it.
  $storeStub = [regex]'WindowsApps\\(python|python3)\.exe$'

  # Prefer the real "py" launcher (comes with python.org installer)
  $pyLauncher = Get-Command py -ErrorAction SilentlyContinue
  if ($pyLauncher -and ($pyLauncher.Source -notmatch $storeStub)) {
    # py -3 picks the *latest* 3.x (e.g. 3.15 alpha). Pin stable: $env:MT5_PYTHON_VERSION = "3.13"
    $pyVerArg = '-3'
    if ($env:MT5_PYTHON_VERSION -and $env:MT5_PYTHON_VERSION.Trim().Length -gt 0) {
      $v = $env:MT5_PYTHON_VERSION.Trim()
      if ($v -notmatch '^\d+\.\d+') {
        Write-Host "MT5_PYTHON_VERSION should be like 3.13 - got: $v" -ForegroundColor Yellow
      } else {
        $pyVerArg = "-$v"
      }
    }
    return @{ Exe = $pyLauncher.Source; Args = @($pyVerArg) }
  }

  foreach ($name in 'python', 'python3') {
    $cmds = @(Get-Command $name -All -ErrorAction SilentlyContinue)
    foreach ($c in $cmds) {
      if ($c.Source -match $storeStub) { continue }
      return @{ Exe = $c.Source; Args = @() }
    }
  }

  return $null
}

Write-Host "=== MT5 Bridge (Windows) ===" -ForegroundColor Cyan
Write-Host ""

if (-not $env:MT5_FILES_DIR -or $env:MT5_FILES_DIR.Trim().Length -eq 0) {
  $detected = Find-BestMt5FilesDir
  if ($detected) {
    $env:MT5_FILES_DIR = $detected
    Write-Host "Detected MT5_FILES_DIR: $($env:MT5_FILES_DIR)"
  } else {
    Write-Host "Could not auto-detect MT5 MQL5\Files folder under AppData." -ForegroundColor Yellow
    Write-Host "Starting bridge anyway: Python will use repo mt5-commands / mt5-responses next to mt5-bridge." -ForegroundColor Yellow
    Write-Host "For live MT5: install and open MetaTrader 5 once, then restart; or set:" -ForegroundColor Gray
    Write-Host '  $env:MT5_FILES_DIR = "$env:APPDATA\MetaQuotes\Terminal\<HASH>\MQL5\Files"' -ForegroundColor Gray
    Write-Host "List terminal folders: Get-ChildItem `"$env:APPDATA\MetaQuotes\Terminal`" -Directory" -ForegroundColor Gray
    Write-Host ""
  }
} else {
  Write-Host "Using MT5_FILES_DIR: $($env:MT5_FILES_DIR)"
}

if ($env:MT5_FILES_DIR -match 'PASTE_|HERE$|\\Files_HERE') {
  Write-Host "MT5_FILES_DIR looks like a placeholder. Clear it or set a real path, e.g.:" -ForegroundColor Red
  Write-Host '  Remove-Item Env:MT5_FILES_DIR' -ForegroundColor Gray
  Write-Host '  $env:MT5_FILES_DIR = "$env:APPDATA\MetaQuotes\Terminal\E3E3B02889D32F38295D39BF94B6AD4A\MQL5\Files"' -ForegroundColor Gray
  exit 1
}

# Repo root: either TRADEINTELAI_ROOT (if you moved scripts) or ...\tradeintelai (two levels up from this folder)
if ($env:TRADEINTELAI_ROOT -and $env:TRADEINTELAI_ROOT.Trim().Length -gt 0) {
  $repoRoot = (Resolve-Path -LiteralPath $env:TRADEINTELAI_ROOT.Trim()).Path
  Write-Host "Using TRADEINTELAI_ROOT: $repoRoot" -ForegroundColor Cyan
} else {
  # PSScriptRoot should be ...\tradeintelai\mt5-bridge\windows
  $repoRoot = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
}
$bridgeDir = Join-Path $repoRoot "mt5-bridge"
$bridgePy  = Join-Path $bridgeDir "wine-mt5-connector.py"

if (-not (Test-Path -LiteralPath $bridgePy)) {
  Write-Host "Bridge file not found: $bridgePy" -ForegroundColor Red
  Write-Host ""
  Write-Host "This folder is NOT C:\Windows and NOT C:\Users\windows." -ForegroundColor Yellow
  # Single-quoted: avoids PowerShell parsing '<' and trailing '\' before '"' as broken strings
  Write-Host 'Scripts must live at:  YOUR_CLONE\mt5-bridge\windows' -ForegroundColor Yellow
  Write-Host "You need the full repo (at least the mt5-bridge folder with wine-mt5-connector.py)." -ForegroundColor Yellow
  Write-Host ""
  Write-Host 'To run:  cd YOUR_CLONE  then  .\mt5-bridge\windows\StartBridge.bat' -ForegroundColor Gray
  Write-Host 'Do not use:  cd StartBridge.bat  (use .\StartBridge.bat to RUN it)' -ForegroundColor Gray
  Write-Host ""
  Write-Host "Or set repo path, then run this script from anywhere:" -ForegroundColor Yellow
  Write-Host '  $env:TRADEINTELAI_ROOT = "C:\Users\Admin\tradeintelai"' -ForegroundColor Gray
  exit 1
}

$launch = Resolve-PythonLaunch
if (-not $launch) {
  Write-Host "Python was not found, or only the Microsoft Store stub is on PATH." -ForegroundColor Red
  Write-Host "Install Python 3.10+ from https://www.python.org/downloads/windows/" -ForegroundColor Yellow
  Write-Host "In the installer: enable 'Add python.exe to PATH' and install the 'py launcher'." -ForegroundColor Yellow
  Write-Host "Then close this window, open a NEW PowerShell, and run StartBridge again." -ForegroundColor Yellow
  Write-Host ""
  Write-Host "Optional: Settings - Apps - Advanced app settings - App execution aliases:" -ForegroundColor Gray
  Write-Host "  Turn OFF python.exe and python3.exe (stops the fake Store shortcut)." -ForegroundColor Gray
  exit 1
}

$logsDir = Join-Path $PSScriptRoot "logs"
New-Item -ItemType Directory -Force -Path $logsDir | Out-Null

$ts = Get-Date -Format "yyyyMMdd-HHmmss"
# PowerShell Start-Process cannot use the same path for stdout and stderr
$logOut = Join-Path $logsDir "bridge-$ts.out.log"
$logErr = Join-Path $logsDir "bridge-$ts.err.log"
New-Item -ItemType File -Force -Path $logOut | Out-Null
New-Item -ItemType File -Force -Path $logErr | Out-Null

if (-not $env:MT5_BRIDGE_PORT -or $env:MT5_BRIDGE_PORT.Trim().Length -eq 0) {
  $env:MT5_BRIDGE_PORT = "8080"
}

Write-Host "Repo root:    $repoRoot"
Write-Host "Bridge dir:   $bridgeDir"
$launchArgsDisplay = [string]::Join(' ', @($launch.Args))
Write-Host "Python:       $($launch.Exe) $launchArgsDisplay"
Write-Host "Port:         $($env:MT5_BRIDGE_PORT)"
Write-Host "Log stdout:   $logOut"
Write-Host "Log stderr:   $logErr"
Write-Host ""
Write-Host "Starting bridge..." -ForegroundColor Green

$argList = @()
$argList += $launch.Args
$argList += $bridgePy

$p = Start-Process -FilePath $launch.Exe -ArgumentList $argList -WorkingDirectory $bridgeDir `
  -RedirectStandardOutput $logOut -RedirectStandardError $logErr -PassThru -WindowStyle Hidden

Start-Sleep -Seconds 2

if ($p.HasExited) {
  Write-Host "Bridge process exited immediately (exit code: $($p.ExitCode))." -ForegroundColor Red
  Write-Host "--- stdout ---" -ForegroundColor Yellow
  Get-Content -LiteralPath $logOut -ErrorAction SilentlyContinue
  Write-Host "--- stderr ---" -ForegroundColor Yellow
  Get-Content -LiteralPath $logErr -ErrorAction SilentlyContinue
  exit 1
}

try {
  $healthUrl = "http://localhost:$($env:MT5_BRIDGE_PORT)/health"
  $resp = Invoke-WebRequest -Uri $healthUrl -UseBasicParsing -TimeoutSec 5
  Write-Host "Health check OK: $($resp.StatusCode) $healthUrl" -ForegroundColor Green
} catch {
  Write-Host "Health check failed: $($_.Exception.Message)" -ForegroundColor Yellow
  Write-Host "If Python failed, check: $logOut and $logErr" -ForegroundColor Yellow
  Get-Content -LiteralPath $logOut -Tail 30 -ErrorAction SilentlyContinue
  Get-Content -LiteralPath $logErr -Tail 30 -ErrorAction SilentlyContinue
}

Write-Host ""
Write-Host "Bridge PID: $($p.Id)  |  Stop: Stop-Process -Id $($p.Id)" -ForegroundColor Cyan
Write-Host "Tailing log (Ctrl+C stops tail only; bridge keeps running):" -ForegroundColor Gray
Write-Host ""

try {
  Get-Content -LiteralPath $logOut -Wait -Tail 20
} finally {
  Write-Host ""
  Write-Host "Log tail ended. Bridge may still be running (PID $($p.Id))." -ForegroundColor Gray
}
